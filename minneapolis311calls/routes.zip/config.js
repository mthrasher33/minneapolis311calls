﻿var config = {
    production: {
        //connection info to MySQL database
        database: {
            host: 'coldlikeminnesota.c44css47zkdo.us-west-2.rds.amazonaws.com',
            user: 'master',
            password: 'bromball1408landlordmonty',
            database: 'address_data',
            connectionLimit: 10
        }
    }
};
module.exports = config;